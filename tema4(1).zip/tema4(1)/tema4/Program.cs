﻿using System;

namespace BankDepositAnalyzer
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("--- Система анализа депозита ---");

            try
            {
                Console.Write("Введите текущий баланс: ");
                string balanceInput = Console.ReadLine();
                double balance = Convert.ToDouble(balanceInput);

                Console.Write("Введите сумму для снятия: ");
                string amountInput = Console.ReadLine();
                double amount = Convert.ToDouble(amountInput);

                if (amount > balance)
                {
                    throw new InvalidOperationException("Недостаточно средств на счете.");
                }

                if (amount < 0)
                {
                    throw new ArgumentException("Сумма снятия не может быть отрицательной.");
                }

                double finalBalance = balance - amount;
                Console.WriteLine($"Успешно! Остаток на счете: {finalBalance}");
            }
            catch (FormatException ex)
            {
                Console.WriteLine($"Ошибка формата: {ex.Message}");
                Console.WriteLine("Пожалуйста, вводите только числа.");
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine($"Ошибка операции: {ex.Message}");
            }
            catch (ArgumentException ex)
            {
                Console.WriteLine($"Ошибка аргумента: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Непредвиденная ошибка: {ex.Message}");
            }
            finally
            {
                Console.WriteLine("--- Работа программы завершена ---");
            }
        }
    }
}
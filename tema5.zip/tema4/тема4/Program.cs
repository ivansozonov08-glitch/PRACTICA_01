﻿using System;

class Program
{
    static void Main()
    {
        string text = "hello world";

        Console.WriteLine(string.Compare("apple", "banana")); 
        Console.WriteLine("hello".Equals("hello"));
        Console.WriteLine(string.CompareOrdinal("Z", "a"));
        Console.WriteLine(text.IndexOf("world"));
        Console.WriteLine(text.Contains("world"));
    }
}
﻿using System;

namespace ClassLibrary1{
    public class Calculator
    {
        public void PrintSum(int a, int b)
        {
            Console.WriteLine($"    Сумма {a} и {b} = {a + b}");
        }

        public void PrintDivide(int a, int b)
        {
            if (b == 0)
            {
                Console.WriteLine("    Деление на ноль недопустимо");
                return;
            }
            Console.WriteLine($"    Частное {a} и {b} = {(double)a / b}");
        }

        public int Add(int a, int b)
        {
            return a + b;
        }

        public double Divide(int a, int b)
        {
            if (b == 0)
                throw new DivideByZeroException();
            return (double)a / b;
        }

        public string GetGreeting(string name)
        {
            return $"    Привет, {name}!";
        }
    }
}
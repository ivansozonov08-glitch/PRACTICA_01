﻿using System;
using System.Collections.Generic;

namespace tema2
{
    public class User
    {
        public int Id { get; set; }
        public string Login { get; set; }
        public string DisplayName { get; set; }
        public string Email { get; set; }
        public string PasswordHash { get; set; }
        public DateTime RegisteredAt { get; set; } = DateTime.UtcNow;
        public DateTime? LastLoginAt { get; set; }
        public bool IsActive { get; set; } = true;
        public string Role { get; set; } = "Покупатель";
        public string AvatarUrl { get; set; }
        public List<string> Addresses { get; set; } = new List<string>();

        public User(int id, string login, string email)
        {
            Id = id;
            Login = login;
            Email = email;
            DisplayName = login;
        }

        public override string ToString()
        {
            return $"Пользователь #{Id}: {DisplayName} ({Email}), Роль={Role}, Активен={IsActive}";
        }
    }
}
﻿using System;

namespace tema2
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Задание 1:");
            Console.WriteLine("    Сложение и деление чисел");

            var calc = new Calculator();
            Console.WriteLine($"    Сумма 10 и 5 = {calc.Add(10, 5)}");
            Console.WriteLine($"    Частное 10 и 4 = {calc.Divide(10, 4)}");

            Console.WriteLine();

            Console.WriteLine("Задание 2:");
            Console.WriteLine("    Класс User");

            var user = new User(1, "ivan_2024", "ivan@example.com")
            {
                DisplayName = "Иван Иванов",
                Role = "Покупатель"
            };
            user.Addresses.Add("г. Москва, ул. Ленина, д. 1");
            Console.WriteLine($"    {user}");
        }
    }
}
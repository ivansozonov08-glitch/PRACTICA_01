﻿using System;

namespace tema2
{
    public class Calculator
    {
        public int Add(int a, int b)
        {
            return a + b;
        }

        private double Dev(int a, int b)
        {
            if (b == 0)
                throw new DivideByZeroException();
            return (double)a / b;
        }

        public double Divide(int a, int b)
        {
            return Dev(a, b);
        }
    }
}